//
//  ViewController.swift
//  Calculator
//
//  Created by cse on 6/16/18.
//  Copyright © 2018 cse. All rights reserved.
//

import UIKit
import Foundation

class ViewController: UIViewController,UITextFieldDelegate{
    
    @IBOutlet weak var calculatorName: UILabel!
    @IBOutlet weak var calType: UISegmentedControl!
    @IBOutlet weak var intName: UILabel!
    
    @IBOutlet weak var switchType: UISwitch!
    @IBOutlet weak var double: UILabel!
    @IBOutlet weak var firstNumber: UILabel!
    @IBOutlet weak var firstnameText: UITextField!
    @IBOutlet weak var secondNumber: UILabel!
    @IBOutlet weak var secondnumberText: UITextField!
    @IBOutlet weak var operations: UILabel!
    @IBOutlet weak var addButton: UIButton!
    @IBOutlet weak var subtractButton: UIButton!
    @IBOutlet weak var multiplyButton: UIButton!
    @IBOutlet weak var divideButton: UIButton!
    @IBOutlet weak var modButton: UIButton!
    @IBOutlet weak var powerButton: UIButton!
    @IBOutlet weak var resultButton: UIButton!
    
    @IBOutlet weak var outputLabel: UILabel!
    
    
    @IBOutlet weak var advanceView: UIView!
    @IBOutlet weak var numLabel: UILabel!
    @IBOutlet weak var aLabel: UILabel!
    @IBOutlet weak var aText: UITextField!
    @IBOutlet weak var bLabel: UILabel!
    @IBOutlet weak var bText: UITextField!
    @IBOutlet weak var cLabel: UILabel!
    @IBOutlet weak var cText: UITextField!
    @IBOutlet weak var lowerLabel: UILabel!
    @IBOutlet weak var lowerText: UITextField!
    @IBOutlet weak var upperLabel: UILabel!
    @IBOutlet weak var upperText: UITextField!
    @IBOutlet weak var percisionLabel: UILabel!
    @IBOutlet weak var percisionText: UITextField!
    
    var dX:Float = 0.0
    var count:Float = 0.0
    var a1:Float = 0.0
    var b1:Float = 0.0
    var c1:Float = 0.0
    var calculation:Float = 0.0
   
    func alertbox(msg:String)
    {
        let myalert = UIAlertController(title: "Alert", message: "\(msg)", preferredStyle: UIAlertControllerStyle.alert)
        myalert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: nil))
        self.present(myalert, animated: true, completion: nil)
    }
    
    
    @IBAction func selectcalType(_ sender: Any) {
        if calType.selectedSegmentIndex == 0{
            advanceView.isHidden = true
        } else {
            advanceView.isHidden = false
        }
    }
    
    
    @IBAction func selectSwitch(_ sender: Any) {
                
       
    }
    

    @IBAction func doAdd(_ sender: Any) {
        if switchType.isOn{
            let first = Double(firstnameText.text!)
            let second = Double(secondnumberText.text!)
            let output = Double(first! + second!)
            let output1 = String(format: "%.2f", output)
            outputLabel.text = "The result is \(output1)"
            
        } else {
            let first = Int(firstnameText.text!)
            let second = Int(secondnumberText.text!)
                   let output = Int(first! + second!)
            outputLabel.text = "The result is \(output)"
        }
        
            
    }
    
    
    @IBAction func doSubtract(_ sender: Any) {
        
        if switchType.isOn{
            let first = Double(firstnameText.text!)
            let second = Double(secondnumberText.text!)
            let output = Double(first! - second!)
            let output1 = String(format: "%.2f", output)
            outputLabel.text = "The result is \(output1)"
        } else {
            let first = Int(firstnameText.text!)
            let second = Int(secondnumberText.text!)
            let output = Int(first! - second!)
            outputLabel.text = "The result is \(output)"
        }
    }
    
    @IBAction func doMultiply(_ sender: Any) {
        if switchType.isOn{
            let first = Double(firstnameText.text!)
            let second = Double(secondnumberText.text!)
            let output = Double(first! * second!)
            let output1 = String(format: "%.2f", output)
            outputLabel.text = "The result is \(output1)"
        } else {
            let first = Int(firstnameText.text!)
            let second = Int(secondnumberText.text!)
            let output = Int(first! * second!)
            outputLabel.text = "The result is \(output)"
        }
    }
    
    @IBAction func doDivide(_ sender: Any) {
        if switchType.isOn{
            let first = Double(firstnameText.text!)
            let second = Double(secondnumberText.text!)
            let output = Double(first! / second!)
            let output1 = String(format: "%.2f", output)
            outputLabel.text = "The result is \(output1)"
        } else {
            let first = Int(firstnameText.text!)
            let second = Int(secondnumberText.text!)
            let output = Int(first! / second!)
            outputLabel.text = "The result is \(output)"
        }
    }
    
    
    @IBAction func doMod(_ sender: Any) {
        if switchType.isOn{
            let first = Double(firstnameText.text!)
            let second = Double(secondnumberText.text!)
            outputLabel.text = "Mod operation does not take the double value"
        } else {
            let first = Int(firstnameText.text!)
            let second = Int(secondnumberText.text!)
            let output = Int(first! % second!)
            outputLabel.text = "The result is \(output)"
        }
    }
    
    
    @IBAction func doPower(_ sender: Any) {
        if switchType.isOn{
            let first = Double(firstnameText.text!)
            let second = Double(secondnumberText.text!)
            let output = pow(first! , second!)
            let output1 = String(format: "%.2f", output)
            outputLabel.text = "The result is \(output1)"
        } else {
            let first = Int(firstnameText.text!)
            let second = Int(secondnumberText.text!)
            let output = Int(first! ^ second!)
            outputLabel.text = "The result is \(output)"
        }
    }
    
    @IBAction func calResult(_ sender: Any) {
    let a = Float(aText.text!)
    let b = Float(bText.text!)
    let c = Float(cText.text!)
    let lower = Float(lowerText.text!)
    let upper = Float(upperText.text!)
    let precision = Float(percisionText.text!)
    

    if a == nil ||
       b == nil ||
       c == nil ||
       lower == nil ||
       upper == nil ||
       precision == nil
    {
        alertbox(msg: "Please enter integer values only")
        }
    if aText.text == ""  ||
            bText.text == "" ||
            cText.text == "" ||
            lowerText.text == "" ||
            upperText.text == "" ||
            percisionText.text == ""
    {
        alertbox(msg: "Please enter all values")
    } else {
        dX = ( upper! - lower! )/precision!
         count = 0.0
        
        for i in stride(from: lower!, to: upper!, by: dX)
        {
            a1 = a! * pow(i,3)
            b1 = b! * pow(i,2)
            c1 = c! * i
            if i == lower! || i == upper!
            {
                count = count + a1 + b1 + c1
            }
            else
            {
                count = count + 2*(a1 + b1 + c1)
            }
        }
        }
        calculation = count * (dX/2)
        outputLabel.text = String(calculation)
        
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        self.view.endEditing(true)
        return false
        }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        advanceView.isHidden = true
        switchType.isOn = false
       }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

